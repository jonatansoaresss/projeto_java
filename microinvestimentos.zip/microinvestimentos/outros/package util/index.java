package util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * classe responsabel pela conexão com o banco postgr.
 */
public class DBConnection {
    private static final String URL = "jdbc:postgresql://localhost:5432/microinvest_db";
    private static final String USER = "postgres";
    private static final String PASS = "9909123";

    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASS);
    }
}