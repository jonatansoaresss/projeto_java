package view;

import dao.InvestimentoDAO;
import model.Investimento;
import java.util.List;
import java.util.Scanner;

/**
 * Interface de console para testar o crud.
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        InvestimentoDAO dao = new InvestimentoDAO();

        while (true) {
            System.out.println("\n--- MICROINVESTIMENTOS COLABORATIVOS ---");
            System.out.println("1 - Criar investimento");
            System.out.println("2 - Listar");
            System.out.println("3 - Atualizar");
            System.out.println("4 - Deletar");
            System.out.println("5 - Sair");
            System.out.print("Escolha: ");

            int op = sc.nextInt();
            sc.nextLine();

            try {
                if (op == 1) {
                    System.out.print("Nome: ");
                    String nome = sc.nextLine();
                    System.out.print("Valor: ");
                    double valor = sc.nextDouble();
                    dao.criar(new Investimento(0, nome, valor));
                    System.out.println("Criado!");

                } else if (op == 2) {
                    List<Investimento> lista = dao.listar();
                    lista.forEach(inv -> System.out.println(inv.getId() + " - " + inv.getNome() + " - R$" + inv.getValor()));

                } else if (op == 3) {
                    System.out.print("ID do investimento: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Novo nome: ");
                    String nome = sc.nextLine();
                    System.out.print("Novo valor: ");
                    double valor = sc.nextDouble();
                    dao.atualizar(new Investimento(id, nome, valor));
                    System.out.println("Atualizado!");

                } else if (op == 4) {
                    System.out.print("ID a deletar: ");
                    int id = sc.nextInt();
                    dao.deletar(id);
                    System.out.println("Deletado!");

                } else if (op == 5) {
                    break;
                }

            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }

        sc.close();
    }
}