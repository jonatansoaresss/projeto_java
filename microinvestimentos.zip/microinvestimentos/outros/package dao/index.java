package dao;

import model.Investimento;
import util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO para operações CRUD
 */
public class InvestimentoDAO {

    public void criar(Investimento inv) throws Exception {
        String sql = "INSERT INTO investimentos (nome, valor) VALUES (?, ?)";
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, inv.getNome());
        stmt.setDouble(2, inv.getValor());
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public List<Investimento> listar() throws Exception {
        List<Investimento> lista = new ArrayList<>();
        String sql = "SELECT * FROM investimentos";
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            lista.add(new Investimento(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getDouble("valor")
            ));
        }

        rs.close();
        stmt.close();
        conn.close();
        return lista;
    }

    public void atualizar(Investimento inv) throws Exception {
        String sql = "UPDATE investimentos SET nome = ?, valor = ? WHERE id = ?";
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, inv.getNome());
        stmt.setDouble(2, inv.getValor());
        stmt.setInt(3, inv.getId());
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public void deletar(int id) throws Exception {
        String sql = "DELETE FROM investimentos WHERE id = ?";
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }
}