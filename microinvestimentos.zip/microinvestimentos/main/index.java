// estrutura do projeto


package model;

/**
 * classe que representa um investiment
 */
public class Investimento {
    private int id;
    private String nome;
    private double valor;

    public Investimento() {}

    public Investimento(int id, String nome, double valor) {
        this.id = id;
        this.nome = nome;
        this.valor = valor;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }
}


package dao;

import model.Investimento;
import util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO para operações CRUD
 */
public class InvestimentoDAO {

    public void criar(Investimento inv) throws Exception {
        String sql = "INSERT INTO investimentos (nome, valor) VALUES (?, ?)";
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, inv.getNome());
        stmt.setDouble(2, inv.getValor());
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public List<Investimento> listar() throws Exception {
        List<Investimento> lista = new ArrayList<>();
        String sql = "SELECT * FROM investimentos";
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            lista.add(new Investimento(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getDouble("valor")
            ));
        }

        rs.close();
        stmt.close();
        conn.close();
        return lista;
    }

    public void atualizar(Investimento inv) throws Exception {
        String sql = "UPDATE investimentos SET nome = ?, valor = ? WHERE id = ?";
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, inv.getNome());
        stmt.setDouble(2, inv.getValor());
        stmt.setInt(3, inv.getId());
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }

    public void deletar(int id) throws Exception {
        String sql = "DELETE FROM investimentos WHERE id = ?";
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }
}


package util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * classe responsabel pela conexão com o banco postgr.
 */
public class DBConnection {
    private static final String URL = "jdbc:postgresql://localhost:5432/microinvest_db";
    private static final String USER = "postgres";
    private static final String PASS = "9909123";

    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASS);
    }
}


package view;

import dao.InvestimentoDAO;
import model.Investimento;
import java.util.List;
import java.util.Scanner;

/**
 * Interface de console para testar o crud.
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        InvestimentoDAO dao = new InvestimentoDAO();

        while (true) {
            System.out.println("\n--- MICROINVESTIMENTOS COLABORATIVOS ---");
            System.out.println("1 - Criar investimento");
            System.out.println("2 - Listar");
            System.out.println("3 - Atualizar");
            System.out.println("4 - Deletar");
            System.out.println("5 - Sair");
            System.out.print("Escolha: ");

            int op = sc.nextInt();
            sc.nextLine();

            try {
                if (op == 1) {
                    System.out.print("Nome: ");
                    String nome = sc.nextLine();
                    System.out.print("Valor: ");
                    double valor = sc.nextDouble();
                    dao.criar(new Investimento(0, nome, valor));
                    System.out.println("Criado!");

                } else if (op == 2) {
                    List<Investimento> lista = dao.listar();
                    lista.forEach(inv -> System.out.println(inv.getId() + " - " + inv.getNome() + " - R$" + inv.getValor()));

                } else if (op == 3) {
                    System.out.print("ID do investimento: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Novo nome: ");
                    String nome = sc.nextLine();
                    System.out.print("Novo valor: ");
                    double valor = sc.nextDouble();
                    dao.atualizar(new Investimento(id, nome, valor));
                    System.out.println("Atualizado!");

                } else if (op == 4) {
                    System.out.print("ID a deletar: ");
                    int id = sc.nextInt();
                    dao.deletar(id);
                    System.out.println("Deletado!");

                } else if (op == 5) {
                    break;
                }

            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }

        sc.close();
    }
}

CREATE DATABASE microinvest_db;

CREATE TABLE investimentos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    valor DOUBLE PRECISION NOT NULL
);
);